<?php
include_once('hms/include/config.php');
if(isset($_POST['submit']))
{
$fname=$_POST['firstname'];
$lname=$_POST['lastname'];
$email=$_POST['emailid'];
$mobileno=$_POST['mobileno'];
$aadhaarno=$_POST['aadhaarno'];
$address=$_POST['address'];
$gender=$_POST['gender'];
$password=$_POST['password'];
$dob=$_POST['dob'];
$query1=mysqli_query($con,"insert into aadhaar_detail(aadhaar_id,f_name,l_name,mobile_no,email,dob,gender,address) value('$aadhaarno','$fname','$lname','$mobileno','$email','$dob','$gender','$address')");
$query2=mysqli_query($con,"insert into patient(aadhaar_id,password,mobile_no,email) value('$aadhaarno','$password','$mobileno','$email')");

echo "<script>alert('Your information succesfully submitted');</script>";
echo "<script>window.location.href ='registration.php'</script>";

}


?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>VIDA | Registration Form</title>
		<link href="css/style.css" rel="stylesheet" type="text/css"  media="all" />
		<link href='http://fonts.googleapis.com/css?family=Ropa+Sans' rel='stylesheet' type='text/css'>
	</head>
	<body>
		<!--start-wrap-->
		
			<!--start-header-->
			<div class="header">
				<div class="wrap">
				<!--start-logo-->
				<div class="logo">
		<a href="index.html" style="font-size: 30px;">Registration Form</a> 
				</div>
				<!--end-logo-->
				<!--start-top-nav-->
				<div class="top-nav">
					<ul>
						<li><a href="index.html">Home</a></li>
					
						<li class="active"><a href="registration.php">Registration</a></li>
					</ul>					
				</div>
				<div class="clear"> </div>
				<!--end-top-nav-->
			</div>
			<!--end-header-->
		</div>
		    <div class="clear"> </div>
		   <div class="wrap">
		   	<div class="contact">
		   	<div class="section group">				
							
				<div class="col span_2_of_3">
                
				  <div class="contact-form">
				  	
					  <br>
					  <br>
					    <form name="registration" method="post">
					    	<div>
						    	<span><label>FIRST NAME</label></span>
						    	<span><input type="text" name="firstname" required="true" value=""></span>
                            </div>
                            <div>
						    	<span><label>LAST NAME</label></span>
						    	<span><input type="text" name="lastname" required="true" value=""></span>
						    </div>
						    <div>
						    	<span><label>E-MAIL</label></span>
						    	<span><input type="email" name="emailid" required="ture" value=""></span>
						    </div>
						    <div>
						     	<span><label>MOBILE NO</label></span>
						    	<span><input type="text" name="mobileno" required="true" value=""></span>
						    </div>
						    <div>
						    	<span><label>AADHAAR NO</label></span>
						    	<span><input type="text" name="aadhaarno" required="true"> </input></span>
						    </div>
							<div>
						    	<span><label>PASSWORD</label></span>
						    	<span><input type="password" name="password" required="true"> </input></span>
                            </div>
                            <div>
						    	<span><label>BIRTH DATE</label></span>
						    	<span><input type="date" name="dob" id="myDate" value="" required="true"> </input></span>
                            </div>
                            <div>
                            <label>
                                <input id="Male" type="radio" name="gender" value="Male" checked> Male
                            </label>
                            <label>
                                <input id="Female" type="radio" name="gender" value="Female" style="margin-left:30px;"> Female
                                <br>
                            </label>  
                            </div>
                            <div>
						    	<span><label>ADDRESS</label></span>
						    	<span><textarea name="address" required="true"> </textarea></span>
						    </div>
						   <div>
						   		<span><input type="submit" name="submit" value="Submit"></span>
						  </div>

					    </form>
                    </div>
  				</div>				
			  </div>
			  	 <div class="clear"> </div>
	</div>
	
	</body>
</html>

