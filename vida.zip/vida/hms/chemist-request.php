<?php
include_once('include/config.php');
if(isset($_POST['submit']))
{
    $chemistname=$_POST['cname'];
$chemistspecialization=$_POST['cspecialization'];
$chemistaddress=$_POST['caddress'];
$chemistcontactno=$_POST['ccontact'];
$chemistid=$_POST['cid'];
$chemistemail=$_POST['cemail'];
$password=($_POST['npass']);
$sql=mysqli_query($con,"insert into chemist_request(chemist_name,specialization,address,mobile_no,chemist_id,email,password)values('$chemistname','$chemistspecialization','$chemistaddress','$chemistcontactno','$chemistid','$chemistemail','$password')");
if($sql)
    {
    echo "<script>alert('Your request registered successfully!!!');</script>";
    
    }
}
?>


<!DOCTYPE html>
<html lang="en">

	<head>
		<title>Chemist Request</title>
		
		<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="vendor/themify-icons/themify-icons.min.css">
		<link href="vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
		<link href="vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
		<link href="vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
		<link rel="stylesheet" href="assets/css/styles.css">
		<link rel="stylesheet" href="assets/css/plugins.css">
		<link rel="stylesheet" href="assets/css/themes/theme-1.css" id="skin_color" />
		
		<script type="text/javascript">
function valid()
{
 if(document.registration.password.value!= document.registration.password_again.value)
{
alert("Password and Confirm Password Field do not match  !!");
document.registration.password_again.focus();
return false;
}
return true;
}
</script>
<script>
function checkemailAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "check_availability_chemist.php",
data:'emailid='+$("#chemistemail").val(),
type: "POST",
success:function(data){
$("#email-availability-status").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}
</script>		

	</head>

	<body class="login">
		<!-- start: REGISTRATION -->
		<div class="row">
			<div class="main-login col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
				<div class="logo margin-top-30">
				<a href="../index.html"><h2>Vida | Chemist Account Request</h2></a>
				</div>
				<!-- start: REGISTER BOX -->
				<div class="box-register" >
                <form role="form" name="adddoc" method="post" onSubmit="return valid();">
                <fieldset>
                <legend>
								Request For Account
							</legend>
							<p>
								Enter your personal details below:
							</p>
<div class="form-group">
															<label for="laboratorialname">
																 Chemist Name
															</label>
					<input type="text" name="cname" class="form-control"  placeholder="Enter Chemist Name" required="true">
														</div>


<div class="form-group">
															<label for="laboratorialSpecialization">
															Chemist Specialization
															</label>
                                                            <input type="text" name="cspecialization" class="form-control"  placeholder="Enter Chemist specialization" required="true">
														</div>

<div class="form-group">
															<label for="address">
																 Chemist Shop Address
															</label>
					<textarea name="caddress" class="form-control"  placeholder="Enter Chemist Shop Address" required="true"></textarea>
                                                        </div>
<div class="form-group">
									<label for="fess">
																Chemist Contact no.
															</label>
					<input type="text" name="ccontact" class="form-control"  placeholder="Enter Chemist Contact no." required="true">
														</div>

<div class="form-group">
															<label for="fess">
																 Chemist Licence Number
															</label>
					<input type="text" name="cid" class="form-control"  placeholder="Enter Chemist Licence Number" required="true">
														</div>
<div class="form-group">
									<label for="fess">
																 Chemist Email
															</label>
<input type="email" id="chemistemail" name="cemail" class="form-control"  placeholder="Enter Chemist Email id" required="true" onBlur="checkemailAvailability()">
<span id="email-availability-status"></span>
</div>
														<div class="form-group">
															<label for="exampleInputPassword1">
																 Password
															</label>
					<input type="password" name="npass" class="form-control"  placeholder="New Password" required="required">
														</div>
														
<div class="form-group">
															<label for="exampleInputPassword2">
																Confirm Password
															</label>
									<input type="password" name="cfpass" class="form-control"  placeholder="Confirm Password" required="required">
														</div>
														
														
														
														<button type="submit" name="submit" id="submit" class="btn btn-o btn-primary">
															Submit
														</button>
                                                        </fieldset>
													</form>
												
					

				</div>

			</div>
		</div>
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<script src="vendor/jquery-validation/jquery.validate.min.js"></script>
		<script src="assets/js/main.js"></script>
		<script src="assets/js/login.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				Login.init();
			});
		</script>
		
	<script>
function userAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "check_availability.php",
data:'email='+$("#email").val(),
type: "POST",
success:function(data){
$("#user-availability-status1").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}
</script>	
		
	</body>
	<!-- end: BODY -->
</html>